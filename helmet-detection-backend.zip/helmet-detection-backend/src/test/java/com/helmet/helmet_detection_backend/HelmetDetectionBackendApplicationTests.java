package com.helmet.helmet_detection_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelmetDetectionBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
